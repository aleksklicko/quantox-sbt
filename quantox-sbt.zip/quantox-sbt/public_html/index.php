<?php
include_once("../init.php");
include("inc/header.php");
include("pages/main.php");
include("inc/footer.php");
?>
		
    